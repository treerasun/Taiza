﻿Imports System.IO
Imports System.Runtime.Serialization.Json
Imports System.Collections.ObjectModel
Imports System.Text
Public Class ReadAGVSetting

    Public dicLine As New Dictionary(Of String, String)
    Public dicname As New Dictionary(Of String, String)
    Public dicindex As New Dictionary(Of String, String)
    Dim path As String
    Dim append As Boolean
    Dim nameList As New List(Of myName)
    Dim name As New myName()
    Public Class myName
        Public Property Name() As String
            Get
                Return m_Name
            End Get
            Set(ByVal value As String)
                m_Name = value
            End Set
        End Property
        Private m_Name As String
        Public Property Surname() As String
            Get
                Return m_Surname
            End Get
            Set(ByVal value As String)
                m_Surname = value
            End Set
        End Property
        Private m_Surname As String
    End Class
    Public Sub New(ByVal path As String, ByVal append As Boolean)
        Me.path = path
        Me.append = append
    End Sub

    Public Sub insert(ByVal tName As String, ByVal ADD As String)
        name.Name = tName
        name.Surname = ADD
        nameList.Add(name)
    End Sub
    Public Sub Save()
        Dim str As New MemoryStream()
        Dim ser As New DataContractJsonSerializer(nameList.GetType())
        ser.WriteObject(str, nameList)

        str.Position = 0
        Dim sr As New StreamReader(str)

        Dim sw As StreamWriter = File.AppendText(path & ".json")
        WriteText(sr.ReadToEnd(), sw)
        sw.Close()
    End Sub


    Public Sub WriteText(ByVal message As String, ByVal tw As TextWriter)
        tw.WriteLine(message)
    End Sub
#Region "Read File Json"
    Public Class readmyName
        Public Property index() As String
            Get
                Return m_index
            End Get
            Set(ByVal value As String)
                m_index = value
            End Set
        End Property
        Private m_index As String
        Public Property name() As String
            Get
                Return m_Name
            End Get
            Set(ByVal value As String)
                m_Name = value
            End Set
        End Property
        Private m_Name As String
        Public Property address() As String
            Get
                Return m_address
            End Get
            Set(ByVal value As String)
                m_address = value
            End Set
        End Property
        Private m_address As String
        Public Property line() As String
            Get
                Return m_Line
            End Get
            Set(ByVal value As String)
                m_Line = value
            End Set
        End Property
        Private m_Line As String
    End Class
    Public Sub read()
        Dim strJSON As String = File.ReadAllText("D:/IprojectDB/Setting/AGV_Setting.json")
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(strJSON))
        Dim list2 As New ObservableCollection(Of readmyName)
        Dim serializer As New DataContractJsonSerializer(GetType(ObservableCollection(Of readmyName)))
        list2 = DirectCast(serializer.ReadObject(ms), ObservableCollection(Of readmyName))
        dicindex.Clear()
        dicname.Clear()
        dicLine.Clear()
        For Each name As readmyName In list2
            dicindex.Add(name.address.ToString, name.index.ToString())
            dicname.Add(name.address.ToString, name.name.ToString())
            dicLine.Add(name.address.ToString, name.line.ToString())
            '  Tindex(countIndex) = name.index.ToString()
            '   Tname(countIndex) = name.name.ToString()
            '  TAddress(countIndex) = name.address.ToString()
            '  TLine(countIndex) = name.line.ToString()
        Next
    End Sub


    Public Shared Function ReadToObject(ByVal json As String) As readmyName
        Dim deserializedMember As New readmyName()
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(json))
        Dim ser As New DataContractJsonSerializer(deserializedMember.GetType())
        deserializedMember = TryCast(ser.ReadObject(ms), readmyName)
        ms.Close()
        Return deserializedMember
    End Function
#End Region

End Class
