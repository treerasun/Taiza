﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Collections.ObjectModel
Imports System.Text
Public Class ReadResSeting
    Dim path As String
    Dim append As Boolean
    Dim nameList As New List(Of myName)
    Dim name As New myName()
    Public Class myName
        Public Property ID() As String
            Get
                Return m_ID
            End Get
            Set(ByVal value As String)
                m_ID = value
            End Set
        End Property
        Private m_ID As String
        Public Property Responsename() As String
            Get
                Return m_Responsename
            End Get
            Set(ByVal value As String)
                m_Responsename = value
            End Set
        End Property
        Private m_Responsename As String
    End Class
    Public Sub New(ByVal path As String, ByVal append As Boolean)
        Me.path = path
        Me.append = append
    End Sub

    Public Sub insert(ByVal tName As String, ByVal ADD As String)
        name.ID = tName
        name.Responsename = ADD
        nameList.Add(name)
    End Sub
    Public Sub Save()
        Dim str As New MemoryStream()
        Dim ser As New DataContractJsonSerializer(nameList.GetType())
        ser.WriteObject(str, nameList)

        str.Position = 0
        Dim sr As New StreamReader(str)

        Dim sw As StreamWriter = File.AppendText(path & ".json")
        WriteText(sr.ReadToEnd(), sw)
        sw.Close()
    End Sub


    Public Sub WriteText(ByVal message As String, ByVal tw As TextWriter)
        tw.WriteLine(message)
    End Sub

#Region "Read File Json"
    Public Class readmyName
        Public Property ID() As String
            Get
                Return m_id
            End Get
            Set(ByVal value As String)
                m_id = value
            End Set
        End Property
        Private m_id As String
        Public Property Responsename() As String
            Get
                Return m_Responsename
            End Get
            Set(ByVal value As String)
                m_Responsename = value
            End Set
        End Property
        Private m_Responsename As String
    End Class
    Public Sub read(ByRef TID As String(), ByRef TResponsename As String())
        Dim strJSON As String = File.ReadAllText(path)
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(strJSON))
            Dim list2 As New ObservableCollection(Of readmyName)
            Dim serializer As New DataContractJsonSerializer(GetType(ObservableCollection(Of readmyName)))
            list2 = DirectCast(serializer.ReadObject(ms), ObservableCollection(Of readmyName))
            Static countIndex As Integer = 0
            ReDim TID(list2.Count - 1)
            ReDim TResponsename(list2.Count - 1)

            For Each name As readmyName In list2
                TID(countIndex) = name.ID.ToString()
            TResponsename(countIndex) = name.Responsename.ToString()
            countIndex = countIndex + 1
            Next
        End Sub

#End Region

    End Class
