﻿Public Class Record_Form
    Private Sub Record_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class