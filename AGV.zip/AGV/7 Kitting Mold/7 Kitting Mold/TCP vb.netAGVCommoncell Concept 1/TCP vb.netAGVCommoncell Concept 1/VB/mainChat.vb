﻿Option Strict On
Option Infer On

Imports System.ComponentModel
Imports System.IO

Imports System.Text
Imports System.Threading
Imports System.Net
Imports System.Net.Sockets




''' <summary>
''' TCP Chat . 
''' Test Common Model D42 
''' </summary>
''' <remarks></remarks>
Public Class mainChat
    'TCP AGV CONTROL
    Public Shared socketAGVControl As New AGVTcpControl()
    Public Shared FlagTCP As Integer
    Dim P() As Process
    Private WithEvents myChat As New TCPChat
    Private myAdapterName, myPhysicalAddress, myGateway, myDNS, strHostName As String
    Private addr() As IPAddress

    'Rs232 
    Private WithEvents _rs232Send As New RS232
    Private charsInlineSend As Integer = 80  ' def n start
    Private isConnectedSend As Boolean
    Private RXcountSend, TXcountSend As Integer
    Private comparamsSend() As String = RS232.DefaultParams
    Private bufferSend() As Byte

    Private WithEvents _rs232 As New RS232
    Private charsInline As Integer = 80  ' def n start
    Private isConnected As Boolean
    Private RXcount, TXcount As Integer
    Private comparams() As String = RS232.DefaultParams
    Private buffer() As Byte

    'Log File
    Dim logE As LogFile = New LogFile("D:/IprojectDB/Common_Log/Err_log", True)
    'Read From config File
    Private Readconfig As ComConfigure = New ComConfigure()
    'queue
    Dim Queue_signal As Integer
    Public obj As Queue(Of String) = New Queue(Of String)()

    'dictionary
    Dim DicCheckAddToQueue As Dictionary(Of String, String) = New Dictionary(Of String, String)

    Dim strtemp, show_result, Show_ADD, receiveadd, straddcheck, getcell, getadd, getstatus As String
    'function compare cell
    Dim C1, C2, C3 As Integer
    Dim totaltimelastedC1 As String = "2"
    Dim totaltimelastedC2 As String = "4"
    Dim totaltimelastedC3 As String = "6"
    Dim timenow, stamptimeC1, stamptimeC2, stamptimeC3 As Date
    Dim GetcomparetimeC1, GetcomparetimeC2, GetcomparetimeC3 As TimeSpan

    'readJSON setting
    Private ReadPCsetting2 As ReadPCsetting = New ReadPCsetting("D:\\IprojectDB\Setting\PC_Setting.json", True)
    Private ReadAGVSetting2 As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)
    Dim COUNT_SEND As Integer = 10
    Dim Response As String
    Dim Requestsendline As Byte
    Dim responsefromAGV As String
    Dim flagcancel As Boolean

#Region "form"

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckProcess()
        ReadPCsetting2.read()
        ReadAGVSetting2.read()
        ' Check data from TCP/IP ''''''''''''''''''''
        If BackgroundWorker5.IsBusy <> True Then
            BackgroundWorker5.RunWorkerAsync()
        End If
        InitialAGVStartControlThread()
        ' '''''''''''''''''''''''''''''''''''''''''''
        If _rs232Send.IsCheckConnect = False Then
            Me.comparamsSend(RS232.cP.cPort) = Readconfig.cPortSend
            Me.comparamsSend(RS232.cP.cBaud) = Readconfig.cBaudSend
            Me.comparamsSend(RS232.cP.cData) = Readconfig.cDataSend
            Me.comparamsSend(RS232.cP.cParity) = Readconfig.cParitySend
            Me.comparamsSend(RS232.cP.cStop) = Readconfig.cStopSend
            Me.comparamsSend(RS232.cP.cDelay) = Readconfig.cDelaySend
            Me.comparamsSend(RS232.cP.cThreshold) = Readconfig.cThresholdSend
            _rs232Send.connect(comparamsSend)
        End If
        If _rs232.IsCheckConnect = False Then
            Me.comparams(RS232.cP.cPort) = Readconfig.cPortRCV
            Me.comparams(RS232.cP.cBaud) = Readconfig.cBaudRCV
            Me.comparams(RS232.cP.cData) = Readconfig.cDataRCV
            Me.comparams(RS232.cP.cParity) = Readconfig.cParityRCV
            Me.comparams(RS232.cP.cStop) = Readconfig.cStopRCV
            Me.comparams(RS232.cP.cDelay) = Readconfig.cDelayRCV
            Me.comparams(RS232.cP.cThreshold) = Readconfig.cThresholdRCV
            _rs232.connect(comparams)
        End If
        '// Getting Ip address of local machine...
        '// First get the host name of local machine.
        'strHostName = Dns.GetHostName()
        'Dim ipEntry As IPHostEntry = Dns.GetHostEntry(strHostName)
        'addr = ipEntry.AddressList
        'Dim i As Integer
        'For i = 0 To addr.Length - 1

        '    If addr(i).AddressFamily = AddressFamily.InterNetwork Then
        '        StatusLabel_adapter.Text = "host " & strHostName &
        '                                   String.Format(" IP: {0}", addr(i).ToString)
        '        Exit For
        '    End If
        'Next
        '  myChat.connect(Readconfig.RemoteIP, CInt(Readconfig.MyPortHost))
        ' InputBox for start program''''''''''''''''''''
        'Dim message, title, defautValue As String
        'Dim myValue As Object
        'message = "Enter a value cell No.For Start Program "
        'title = "Set up cell use"
        'defautValue = "1"
        'myValue = InputBox(message, title, defautValue, 500, 350)
        'If myValue Is "" Then myValue = defautValue
        ''*''''''''''''''''''''''''''''''''''''''''''''
        'Requestsendline = CByte(myValue)


    End Sub

    Private Sub btn_clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        lbout.Items.Clear()
    End Sub

#End Region
#Region "check process AGV TCP CONTROL running"
    Private Sub CheckProcess()
        P = Process.GetProcessesByName("AGVControlServerConsole")
        If P.Count > 0 Then
            Exit Sub
        Else
            Process.Start("D:\IprojectDB\Setting\AGVControlServerConsole")
        End If
        'D:\IprojectDB\Setting\AGVControlServerConsole
    End Sub
#End Region
#Region "Tcp AGV control"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        'AddHandler BackgroundWorker1.DoWork, AddressOf BackgroundWorker1_DoWork
        'AddHanv  dler BackgroundWorker1.ProgressChanged, AddressOf BackgroundWorker1_ProgressChanged
        'AddHandler BackgroundWorker1.RunWorkerCompleted, AddressOf BackgroundWorker1_RunWorkerCompleted
        BackgroundWorker1.WorkerReportsProgress = True
        BackgroundWorker1.WorkerSupportsCancellation = True
        BackgroundWorker4.WorkerReportsProgress = True
        BackgroundWorker4.WorkerSupportsCancellation = True
        BackgroundWorker5.WorkerReportsProgress = True
        BackgroundWorker5.WorkerSupportsCancellation = True
    End Sub
    Public Sub InitialAGVStartControlThread()
        If Not socketAGVControl.isTryConnecting Then
            socketAGVControl.isTryConnecting = True
            If BackgroundWorker4.IsBusy <> True Then
                BackgroundWorker4.RunWorkerAsync()
            End If
        End If
    End Sub
    Dim log1 As LogFile = New LogFile("D:/IprojectDB/log_start_control", True)
    Private Sub TCPAVGAutoStartControl()
        Try
            Update_label("[AGV auto start: Connecting to " & socketAGVControl.config.MyIPHost & ":" &
                          socketAGVControl.config.MyPortHost & "...]", TstaTCPSignal, Color.LightCyan, Color.Black)
            If socketAGVControl.Connect() Then
                Update_label("[AGV auto start: Connected to " &
                    socketAGVControl.config.MyIPHost & ":" & socketAGVControl.config.MyPortHost & "]", TstaTCPSignal, Color.LightCyan, Color.Black)
                While True
                    Dim s As String = socketAGVControl.sr.ReadLine()
                    If s <> "200" Then
                        Try
                            Dim delimiter() As String = {"|"}
                            Dim resArray() As String = s.Split(delimiter, StringSplitOptions.None)
                            If resArray.Length = 3 Then
                                socketAGVControl.received = socketAGVControl.received + 1
                                AGVTcpControl.Master_cell = resArray(2)
                                AGVTcpControl.Master_process = resArray(1)
                                AGVTcpControl.Master_circleTime = resArray(0)
                                'test.Variable = AGVTcpControl.Master_cell
                                Update_label(socketAGVControl.received & ": " & s, TstaTCPSignal, Color.LightCyan, Color.Black)
                                ' timesignal = Now
                                check_XBADD_inBuffer()
                            End If
                        Catch e As NullReferenceException
                            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 1111")
                            Me.Refresh()
                        End Try
                    End If
                End While
            End If
            socketAGVControl.isTryConnecting = False
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 2222")
            Me.Refresh()
        Catch e As IOException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 3333")
            Me.Refresh()
        End Try
    End Sub

    Public Sub TCPAutoStartControlTimer()
        While True
            Thread.Sleep(5000)
            If Not socketAGVControl.Ping() Then
                InitialAGVStartControlThread()
            End If
            If FlagTCP = 1 Then
                FlagTCP = 0
                socketAGVControl.isTryConnecting = False
            End If
        End While
    End Sub
    Public Sub TcpAGVAutoStartReceive()
        While True
            Try
                Dim s As String = socketAGVControl.sr.ReadLine()
                ' ToolStripStatusLabel1.Text = s
                Update_label(s, TstaTCPSignal, Color.LightCyan, Color.Black)
            Catch e As InvalidOperationException
                log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 9999")
            End Try


        End While
    End Sub
    Private Sub BackgroundWorker4_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker4.DoWork
        TCPAutoStartControlTimer()
    End Sub
    Private Sub BackgroundWorker5_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker5.DoWork
        TCPAVGAutoStartControl()
    End Sub
#End Region
#Region "RS232"
#Region "RS232 Send Port "
    'End Serialport receive code
#Region "form events Send Port"
    Private countsend As Integer
    Private Sub sendToComSend() 'Handles cbxsendToCom.KeyDown
        Dim dataSend() As Byte = Nothing
        Me.TXcountSend += dataSend.Length
        Update_label(String.Format("{0:D6}", TXcountSend), lblTxCntSend, Nothing, Nothing)

    End Sub
    Public Sub Send_cmd_tOagv(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte, ByVal Value As Byte)
        '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 03 52 01 09 
        Dim FSUM As Integer
        FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2 + Value)
        Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
        Dim h As Integer
        h = byteArray(0)
        Dim Packet() As Byte = {&H7E, &H0, &H11, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, Value, CByte(h)}
        If SerialS.IsCheckConnect() = True Then
            SerialS.SendData(Packet)
        End If
    End Sub
    Public Sub Send_cmd_04(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByRef addTSet As Byte()) 'Send_cmd_04(_rs232send,add(),02,addtset())
        '7E 00 14 10 00 00 13 A2 00 40 D5 1A 36 FF FE 00 00 04 02 FF FF FF FF D6
        Dim FSUM As Integer
        FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + &H04 + CMD1 + addTSet(0) + addTSet(1) + addTSet(2) + addTSet(3))
        Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
        Dim h As Integer
        h = byteArray(0)

        Dim Packet() As Byte = {&H7E, &H0, &H14, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, &H04, CMD1, addTSet(0), addTSet(1), addTSet(2), addTSet(3), CByte(h)}
        If SerialS.IsCheckConnect() = True Then
            SerialS.SendData(Packet)
        End If
    End Sub
#End Region
#Region "Com Port class events send Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferSend">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateSend(ByVal bufferSend() As Byte) Handles _rs232Send.Datareceived

        Me.RXcountSend += bufferSend.Length
        '  Me.lblRxCntSend.Text = String.Format("count: {0:D3}", RXcountSend)
        Update_label(String.Format("count: {0:D3}", RXcountSend), lblTxCntSend, Nothing, Nothing)
        Dim sSend As String = Encoding.ASCII.GetString(bufferSend, 0, bufferSend.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataSend(ByVal sendStatusSend As Boolean) Handles _rs232Send.sendOK
        If sendStatusSend Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataSend(ByVal receiveStatusSend As Boolean) Handles _rs232Send.recOK
        If receiveStatusSend Then

        Else

        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionSend(ByVal statusSend As Boolean) Handles _rs232Send.connection
        If statusSend Then
            Me.btnConnectSend.Text = "disconnect"
            Me.sLabelSend(comparamsSend)
            Me.isConnectedSend = True
            Me.txtstatus1.BackColor = Color.ForestGreen
            Me.txtstatus1.ForeColor = Color.Blue
            Me.txtstatus1.Text = "Connect"
        Else
            Me.btnConnectSend.Text = "*connect*"
            Me.txtstatus1.Text = "none"
            Me.isConnectedSend = False
            Me.txtstatus1.BackColor = Color.Red
        End If
    End Sub

    Private Sub getmessageSend(ByVal msgSend As String) Handles _rs232Send.errormsg

        MsgBox(msgSend)
    End Sub

#End Region
#Region "utilities  Send Port"
    Private Sub appendBytesSend(ByVal rb As RichTextBox, ByRef dataSend() As Byte, ByRef currentLenghtSend As Integer, ByVal showHexAndAsciiSend As Boolean)
        Dim HexStringSend As String = String.Empty
        Dim CharStringSend As String = String.Empty
        Dim count As Integer = 0

        For i As Integer = 0 To dataSend.Length - 1
            HexStringSend &= String.Format(" {0:X2}", dataSend(i))
            If dataSend(i) > 31 Then
                CharStringSend &= String.Format("  {0}", Chr(dataSend(i)))
            Else
                CharStringSend &= "  ."
            End If
            count += 3

        Next

    End Sub

    Private Sub sLabelSend(ByVal comparamsSend() As String)
        Update_label(Readconfig.cPortSend, lblGetportSend, Color.Transparent, Color.Black)
    End Sub


#End Region
    Private Sub btnConnectSend_Click(sender As Object, e As EventArgs) Handles btnConnectSend.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then
                Me.comparamsSend(RS232.cP.cPort) = Readconfig.cPortSend
                Me.comparamsSend(RS232.cP.cBaud) = Readconfig.cBaudSend
                Me.comparamsSend(RS232.cP.cData) = Readconfig.cDataSend
                Me.comparamsSend(RS232.cP.cParity) = Readconfig.cParitySend
                Me.comparamsSend(RS232.cP.cStop) = Readconfig.cStopSend
                Me.comparamsSend(RS232.cP.cDelay) = Readconfig.cDelaySend
                Me.comparamsSend(RS232.cP.cThreshold) = Readconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            Else
                _rs232Send.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    'End Serialport send code

#End Region
#Region "RS232 Receive Port"
#Region "form events Receive Port"


    Private count As Integer

    ''' <summary>
    ''' build hex string in textbox
    ''' </summary>
    Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
                                           ByVal e As System.EventArgs)


        '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
        Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
        Dim s As String = cb.Text
        count += 1
        If count = 2 Then
            cb.Text &= " "
            count = 0
        End If
        cb.SelectionStart = cb.Text.Length

    End Sub

    Private Sub sendToCom() 'Handles cbxsendToCom.KeyDown
        Dim data() As Byte = Nothing
        _rs232.SendData(data)
        Me.TXcount += data.Length
    End Sub
    ''' <summary>
    ''' view hex in rx box
    ''' </summary>
    Private Sub RxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '   Me.charsInline = setRuler(Me.rtbRX, Me.chkRxShowHex.Checked)
    End Sub
    ''' <summary>
    ''' view hex in tx box
    ''' </summary>
    Private Sub chkTxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '    Me.charsInline = setRuler(Me.rtbTX, Me.chkTxShowHex.Checked)
    End Sub
    Private Sub frmMain_ResizeEnd(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.ResizeEnd
        'Me.charsInline = setRuler(rtbRX, chkRxShowHex.Checked)
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Update_label(BackgroundWorker1.IsBusy.ToString, lblC1, Color.Transparent, Color.Blue)
        If obj.Count <= 0 Then
            Update_label(BackgroundWorker1.IsBusy.ToString, lblC1, Color.Transparent, Color.Blue)
        End If
    End Sub
#End Region
#Region "Com Port class events Receive Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate(ByVal buffer() As Byte) Handles _rs232.Datareceived

        Me.RXcount += buffer.Length
        ' Me.lblRxCnt.Text = String.Format("count: {0:D3}", RXcount)
        Update_label(String.Format("{0:D3}", RXcount), lblRXCount, Nothing, Nothing)
        Dim s As String = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
        appendBytes(buffer, Me.charsInline, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata(ByVal sendStatus As Boolean) Handles _rs232.sendOK
        If sendStatus Then
            '  Me.statusTX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTX, My.Resources.ledGreen)
        Else
            '   Me.statusTX.Image = My.Resources.ledRed
            '   Update_bitmap(statusTX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdata(ByVal receiveStatus As Boolean) Handles _rs232.recOK
        If receiveStatus Then
            ' Me.statusRX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusRX, My.Resources.ledGreen)
        Else
            ' Me.statusRX.Image = My.Resources.ledRed
            ' Update_bitmap(statusRX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection(ByVal status As Boolean) Handles _rs232.connection
        If status Then

            Me.btnConnectRCV.Text = "disconnect"
            Me.sLabel(comparams)
            Me.isConnected = True
            Me.status0.BackColor = Color.Green
            Me.status0.ForeColor = Color.Blue
            Me.lblGetportrcv.Text = Readconfig.cPortRCV
            Me.status0.Text = "Connect"
        Else

            Me.btnConnectRCV.Text = "*connect*"
            Me.status0.Text = "none"
            Me.isConnected = False
            Me.status0.BackColor = Color.Red
        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage(ByVal msg As String) Handles _rs232.errormsg
        'Me.status0.Text = msg
        MsgBox(msg)
    End Sub

    Private Sub btnConnectRCV_Click(sender As Object, e As EventArgs) Handles btnConnectRCV.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then

                Me.comparams(RS232.cP.cPort) = Readconfig.cPortRCV
                Me.comparams(RS232.cP.cBaud) = Readconfig.cBaudRCV
                Me.comparams(RS232.cP.cData) = Readconfig.cDataRCV
                Me.comparams(RS232.cP.cParity) = Readconfig.cParityRCV
                Me.comparams(RS232.cP.cStop) = Readconfig.cStopRCV
                Me.comparams(RS232.cP.cDelay) = Readconfig.cDelayRCV
                Me.comparams(RS232.cP.cThreshold) = Readconfig.cThresholdRCV
                _rs232.connect(comparams)
            Else
                _rs232.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

#End Region
#Region "utilities  Receive Port"
    ''' <param name="data">data frame</param>
    ''' <param name="currentLenght">possible chars in box</param>
    ''' <param name="showHexAndAscii">determines whether also displaying Hex True</param>
    ''' <remarks></remarks>
    Private Sub appendBytes(ByRef data() As Byte, ByRef currentLenght As Integer, ByVal showHexAndAscii As Boolean)
        Try
            Dim HexString As String = strtemp & StringUltilities.ByteArrayToHexString(data)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            ' Static A As Integer
            Dim objmember As Object() = Nothing
            For i = 0 To s.Length - 1
                ' Update_ToolstripStaLabel(s(i).ToString, TstaTCPSignal, Color.MistyRose)
                Dim data_S() As Byte
                Dim ADD() As Byte
                Dim Respond As Byte
                Dim card() As Byte
                Dim strb As String = Nothing
                Dim strb2 As String = Nothing
                'Dim line As String
                'Dim name As String
                'Dim index As String
                data_S = Reconvert.convert(s(i), " ")
                If data_S.Length = 20 Then
                    strtemp = ""
                    ADD = {data_S(7), data_S(8), data_S(9), data_S(10)}
                    strb = Hex(data_S(7)).PadLeft(2, "0"c) & " " & Hex(data_S(8)).PadLeft(2, "0"c) & " " & Hex(data_S(9)).PadLeft(2, "0"c) & " " & Hex(data_S(10)).PadLeft(2, "0"c)
                    strb2 = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                    Show_ADD = strb2
                    Respond = data_S(16)
                    card = {data_S(18), data_S(17), &H0, &H0}
                    Response = Hex(data_S(17)) & Hex(data_S(18))
                    Dim result As Long = BitConverter.ToUInt32(card, 0)
                    show_result = result.ToString
                    receiveadd = strb
                    ' If strb <> straddcheck Then
                    'straddcheck = strb
                    '  If Not DicCheckAddToQueue.ContainsKey(strb) Then
                    '   DicCheckAddToQueue.Add(strb, "1")


                    Select Case result
                        Case CInt(Readconfig.RFIDCARD) 'cell 3-3 
                            QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                            updateAGVQ(obj, ListInQueue1)
                            Send_cmd_tOagv(_rs232Send, ADD, &H4F, &H4B, &H0) 'send OK Confirm
                            If BackgroundWorker1.IsBusy <> True Then
                                Delay(0.5)
                                BackgroundWorker1.RunWorkerAsync()
                            End If
                        Case 20993 'R1
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route1"
                            End If
                        Case 20994 'R2
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route2"
                            End If
                        Case 20995 'R3
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route3"
                            End If
                        Case 20996 'R4
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route4"
                            End If
                        Case CInt(Readconfig.RFIDCARD_CANCEL) 'card 217
                            If CheckBox1.Checked = True Then
                                If obj.Count > 0 Then
                                    flagcancel = True
                                End If
                                Send_cmd_tOagv(_rs232Send, ADD, &H4F, &H4B, &H0) 'send OK Confirm
                            ElseIf BackgroundWorker1.IsBusy = False Then
                                Send_cmd_tOagv(_rs232Send, ADD, &H4F, &H4B, &H0) 'send OK Confirm
                            End If
                    End Select
                    result = 0
                    For II = 0 To data_S.Length - 1
                        data_S(II) = &H0
                    Next
                End If
            Next
            HexString = String.Empty
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try



    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabel(ByVal comparams() As String)
        Update_label(Readconfig.cPortRCV, lblGetportrcv, Color.Transparent, Color.Black)
    End Sub
#End Region
#End Region
#End Region
#Region "My Function"
    Private Sub updateAGVQ(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        '    Try)
        If objT.Count <> 0 Then
            Dim arr As Object()
            arr = objT.ToArray()
            UpdateStatus("", ListInQueue1)
            For i As Integer = 0 To objT.Count - 1
                UpdateStatus(arr(i).ToString, ListInQueue1)
            Next
        ElseIf objT.Count = 0 Then
            ' ListInQueue.Items.Clear()
            UpdateStatus("", ListInQueue1)
            '  MessageBox.Show("queue is empty")
        End If
    End Sub
    Public Sub check_XBADD_inBuffer()
        Dim Pac(20) As Byte
        Dim addT(3) As Byte
        Dim Card(3) As Byte
        ' Dim res As Byte
        Dim strdata As String = Nothing
        '  Dim Stradd As String
        Update_label("Start" & AGVTcpControl.Master_cell, LblSignalRCV, Color.Gold, Color.Black)
        Try
            Select Case AGVTcpControl.Master_cell
                Case Readconfig.CmdSignal1
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    If BackgroundWorker1.IsBusy <> True Then
                        Update_label("Start" & AGVTcpControl.Master_cell, LblSignalRCV, Color.Gold, Color.Black)
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
                Case Readconfig.CmdSignal2
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    If BackgroundWorker1.IsBusy <> True Then
                        Update_label("Start" & AGVTcpControl.Master_cell, LblSignalRCV, Color.Gold, Color.Black)
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
                Case Readconfig.CmdSignal3
                    Requestsendline = CByte(Readconfig.CmdRouteCell3)
                    If BackgroundWorker1.IsBusy <> True Then
                        Update_label("Start" & AGVTcpControl.Master_cell, LblSignalRCV, Color.Gold, Color.Black)
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
                Case Readconfig.CmdSignal4
                    Requestsendline = CByte(Readconfig.CmdRouteCell4)
                    If BackgroundWorker1.IsBusy <> True Then
                        Update_label("Start" & AGVTcpControl.Master_cell, LblSignalRCV, Color.Gold, Color.Black)
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
            End Select

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Sub CompareDataToSend(ByVal Cell1 As Integer, ByVal Cell2 As Integer, ByVal Cell3 As Integer)
        'time2 = Now
        'timewaitAGV = time2.Subtract(time1)
        'totaltime_wait_AGV = FormatNumber(timewaitAGV.Seconds)
        If Cell1 < Cell2 And Cell1 < Cell3 Then '0 1 1
            Requestsendline = 1
        ElseIf Cell2 < Cell1 And Cell2 < Cell3 Then '1 0 1
            Requestsendline = 2
        ElseIf Cell3 < Cell1 And Cell3 < Cell2 Then '1 1 0
            Requestsendline = 3
        ElseIf (Cell1 > Cell2 And Cell2 = Cell3) Or (Cell1 > Cell3 And Cell2 = Cell3) Then
            timenow = Now
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
            If CInt(totaltimelastedC2) > CInt(totaltimelastedC3) Then
                Requestsendline = 3
            ElseIf CInt(totaltimelastedC2) < CInt(totaltimelastedC3) Then
                Requestsendline = 2
            Else
                Requestsendline = 3
            End If
        ElseIf (Cell2 > Cell1 And Cell1 = Cell3) Or (Cell2 > Cell1 And Cell1 = Cell3) Then
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
            If CInt(totaltimelastedC1) > CInt(totaltimelastedC3) Then
                Requestsendline = 3
            ElseIf CInt(totaltimelastedC1) < CInt(totaltimelastedC3) Then
                Requestsendline = 1
            Else
                Requestsendline = 1
            End If
        ElseIf (Cell3 > Cell1 And Cell1 = Cell2) Or (Cell3 > Cell2 And Cell1 = Cell2) Then
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
            If CInt(totaltimelastedC1) > CInt(totaltimelastedC2) Then
                Requestsendline = 2
            ElseIf CInt(totaltimelastedC1) < CInt(totaltimelastedC2) Then
                Requestsendline = 1
            Else
                Requestsendline = 2
            End If
        ElseIf Cell1 = Cell2 And Cell1 = Cell3 And Cell2 = Cell3 Then
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
            If CInt(totaltimelastedC1) > CInt(totaltimelastedC2) And CInt(totaltimelastedC1) > CInt(totaltimelastedC3) Then
                Requestsendline = 1
            ElseIf CInt(totaltimelastedC2) > CInt(totaltimelastedC1) And CInt(totaltimelastedC2) > CInt(totaltimelastedC3) Then
                Requestsendline = 2
            ElseIf CInt(totaltimelastedC3) > CInt(totaltimelastedC1) And CInt(totaltimelastedC3) > CInt(totaltimelastedC2) Then
                Requestsendline = 3
            End If
            'ElseIf Cell1 = Nothing And Cell2 = Nothing And Cell3 = Nothing Then
            '    Requestsendline = 1
        Else
            Requestsendline = 0
        End If

    End Sub
#End Region
#Region "safety UI Update"
    Private Delegate Sub DelegateUpdateLabel(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
    Private Sub Update_label(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusLabel = "" Then
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                Else
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                End If
            Else
                If strstatusLabel = "" Then
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                Else
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateLog(ByVal StrCSV1 As String)
    Private Sub Update_Log(ByVal StrCSV1 As String)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"))
            Else
                logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateStatus22(ByVal statusText1 As String, ByVal txt As ListBox)
    Private Sub UpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
        Try
            If InvokeRequired Then
                If statusText1 = "" Then
                    Invoke(Sub() txt.Items.Clear())
                Else
                    Invoke(Sub() txt.Items.Add(statusText1))
                End If
            Else
                If statusText1 = "" Then
                    txt.Items.Clear()
                Else
                    txt.Items.Add(statusText1)
                End If
            End If
        Catch ex As Exception
            '  logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color)
    Private Sub Update_ToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripStaLabel = "" Then
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                Else
                    Invoke(Sub() ToolstripStaLabel.Text = strstatusToolstripStaLabel)
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                End If
            Else
                If strstatusToolstripStaLabel = "" Then
                    ToolstripStaLabel.BackColor = lblcolor
                Else
                    ToolstripStaLabel.Text = strstatusToolstripStaLabel
                    ToolstripStaLabel.BackColor = lblcolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
#End Region
#Region "Backgroung1"
    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Dim Pac(20) As Byte
        Dim addT(7) As Byte
        Dim addFixsend(3) As Byte
        Dim Card2(3) As Byte
        Dim res As Byte
        Dim strdata2 As String = Nothing

        Static CountSent As Integer = 0
resend: While True
            If obj.Count > 0 And Requestsendline > 0 And AGVTcpControl.Master_cell <> "" Then
                QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                Do
                    'Update_label("R", Label18, Color.Black, Color.Orange)
                    If CountSent = CInt(Readconfig.SendCount) Or flagcancel = True Then
                        Update_label("Send:" & "TimeOut" & vbCrLf & " Route" & CInt(Requestsendline).ToString, lblAGVName, Color.LightYellow, Color.Orange)
                        CountSent = 0
                        flagcancel = False
                        Exit Do
                    End If
                    CountSent += 1
                    Delay(0.5)
                    Send_cmd_tOagv(_rs232Send, addT, &H3, &H52, Requestsendline)
                    'Update_label("R", Label18, Color.White, Color.Orange)
                Loop Until receiveadd = strdata2 And responsefromAGV = "Route" & CInt(Requestsendline).ToString
                If receiveadd = strdata2 And responsefromAGV = "Route" & CInt(Requestsendline).ToString Then
                    Update_label("Send:" & "Route" & CInt(Requestsendline).ToString & vbCrLf & "OK", lblAGVName, Color.Green, Color.Black)
                    System.Threading.Thread.Sleep(1000)
                End If
                CountSent = 0
                responsefromAGV = ""
                AGVTcpControl.Master_cell = ""
                QueueManage.deDequeue_AGV(obj, ListInQueue1)
                updateAGVQ(obj, ListInQueue1)
                Update_label("Waiting Signal", LblSignalRCV, Color.Gray, Color.Black)
                System.Threading.Thread.Sleep(2000)
                Update_label("Wait AGV:", lblAGVName, Color.Gray, Color.Black)

                If obj.Count > 0 Then
                    GoTo resend
                Else
                    Exit While
                End If
            ElseIf obj.Count <= 0 Then
                Exit While
            End If
        End While
    End Sub
#End Region
End Class


