﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainChat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.StatusLabel_adapter = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusLabel_send = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusLabel_receive = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblC3 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblC2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblC1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbltimeC1 = New System.Windows.Forms.Label()
        Me.lbltimeC2 = New System.Windows.Forms.Label()
        Me.lbltimeC3 = New System.Windows.Forms.Label()
        Me.lbout = New System.Windows.Forms.ListBox()
        Me.TstaTCPSignal = New System.Windows.Forms.Label()
        Me.LblSignalRCV = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblAGVName = New System.Windows.Forms.Label()
        Me.ListInQueue1 = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblGetportrcv = New System.Windows.Forms.Label()
        Me.lblRXCount = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnConnectRCV = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.status0 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblGetportSend = New System.Windows.Forms.Label()
        Me.lblTxCntSend = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnConnectSend = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtstatus1 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker4 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker5 = New System.ComponentModel.BackgroundWorker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel_adapter, Me.StatusLabel_send, Me.StatusLabel_receive})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 720)
        Me.StatusStrip1.MinimumSize = New System.Drawing.Size(361, 22)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(456, 22)
        Me.StatusStrip1.TabIndex = 12
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel_adapter
        '
        Me.StatusLabel_adapter.BorderStyle = System.Windows.Forms.Border3DStyle.Raised
        Me.StatusLabel_adapter.Image = Global.TCPchat.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_adapter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.StatusLabel_adapter.Name = "StatusLabel_adapter"
        Me.StatusLabel_adapter.Size = New System.Drawing.Size(96, 17)
        Me.StatusLabel_adapter.Text = "adapter name"
        Me.StatusLabel_adapter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'StatusLabel_send
        '
        Me.StatusLabel_send.AutoSize = False
        Me.StatusLabel_send.Image = Global.TCPchat.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_send.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.StatusLabel_send.Name = "StatusLabel_send"
        Me.StatusLabel_send.Size = New System.Drawing.Size(70, 17)
        Me.StatusLabel_send.Text = "send data"
        '
        'StatusLabel_receive
        '
        Me.StatusLabel_receive.AutoSize = False
        Me.StatusLabel_receive.Image = Global.TCPchat.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_receive.Name = "StatusLabel_receive"
        Me.StatusLabel_receive.Size = New System.Drawing.Size(70, 17)
        Me.StatusLabel_receive.Text = "receive"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer4)
        Me.SplitContainer1.Size = New System.Drawing.Size(456, 720)
        Me.SplitContainer1.SplitterDistance = 583
        Me.SplitContainer1.TabIndex = 13
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.TableLayoutPanel1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.TableLayoutPanel3)
        Me.SplitContainer2.Size = New System.Drawing.Size(454, 581)
        Me.SplitContainer2.SplitterDistance = 227
        Me.SplitContainer2.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lbout, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TstaTCPSignal, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblSignalRCV, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.89552!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.10448!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 330.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 88.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(223, 577)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.lblC3, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label12, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.lblC2, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label10, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.lblC1, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC1, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC2, 2, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC3, 2, 2)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(4, 469)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 3
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(215, 82)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'lblC3
        '
        Me.lblC3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblC3.AutoSize = True
        Me.lblC3.BackColor = System.Drawing.Color.Transparent
        Me.lblC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC3.Location = New System.Drawing.Point(68, 65)
        Me.lblC3.Name = "lblC3"
        Me.lblC3.Size = New System.Drawing.Size(35, 12)
        Me.lblC3.TabIndex = 21
        Me.lblC3.Text = "Status:"
        Me.lblC3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(4, 61)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(57, 20)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Count Cell3:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblC2
        '
        Me.lblC2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblC2.AutoSize = True
        Me.lblC2.BackColor = System.Drawing.Color.Transparent
        Me.lblC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC2.Location = New System.Drawing.Point(68, 39)
        Me.lblC2.Name = "lblC2"
        Me.lblC2.Size = New System.Drawing.Size(35, 12)
        Me.lblC2.TabIndex = 19
        Me.lblC2.Text = "Status:"
        Me.lblC2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(57, 29)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Count Cell2:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblC1
        '
        Me.lblC1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblC1.AutoSize = True
        Me.lblC1.BackColor = System.Drawing.Color.Transparent
        Me.lblC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC1.Location = New System.Drawing.Point(68, 9)
        Me.lblC1.Name = "lblC1"
        Me.lblC1.Size = New System.Drawing.Size(35, 12)
        Me.lblC1.TabIndex = 17
        Me.lblC1.Text = "Status:"
        Me.lblC1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(4, 1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 29)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Count Cell1:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC1
        '
        Me.lbltimeC1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lbltimeC1.AutoSize = True
        Me.lbltimeC1.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC1.Location = New System.Drawing.Point(111, 9)
        Me.lbltimeC1.Name = "lbltimeC1"
        Me.lbltimeC1.Size = New System.Drawing.Size(17, 12)
        Me.lbltimeC1.TabIndex = 22
        Me.lbltimeC1.Text = "----"
        Me.lbltimeC1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC2
        '
        Me.lbltimeC2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lbltimeC2.AutoSize = True
        Me.lbltimeC2.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC2.Location = New System.Drawing.Point(111, 39)
        Me.lbltimeC2.Name = "lbltimeC2"
        Me.lbltimeC2.Size = New System.Drawing.Size(17, 12)
        Me.lbltimeC2.TabIndex = 23
        Me.lbltimeC2.Text = "----"
        Me.lbltimeC2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC3
        '
        Me.lbltimeC3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lbltimeC3.AutoSize = True
        Me.lbltimeC3.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC3.Location = New System.Drawing.Point(111, 65)
        Me.lbltimeC3.Name = "lbltimeC3"
        Me.lbltimeC3.Size = New System.Drawing.Size(17, 12)
        Me.lbltimeC3.TabIndex = 24
        Me.lbltimeC3.Text = "----"
        Me.lbltimeC3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbout
        '
        Me.lbout.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lbout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbout.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbout.FormattingEnabled = True
        Me.lbout.ItemHeight = 14
        Me.lbout.Location = New System.Drawing.Point(4, 138)
        Me.lbout.Name = "lbout"
        Me.lbout.Size = New System.Drawing.Size(215, 324)
        Me.lbout.TabIndex = 0
        '
        'TstaTCPSignal
        '
        Me.TstaTCPSignal.AutoSize = True
        Me.TstaTCPSignal.Location = New System.Drawing.Point(4, 555)
        Me.TstaTCPSignal.Name = "TstaTCPSignal"
        Me.TstaTCPSignal.Size = New System.Drawing.Size(61, 13)
        Me.TstaTCPSignal.TabIndex = 2
        Me.TstaTCPSignal.Text = "TCP Status"
        '
        'LblSignalRCV
        '
        Me.LblSignalRCV.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblSignalRCV.AutoSize = True
        Me.LblSignalRCV.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSignalRCV.Location = New System.Drawing.Point(4, 29)
        Me.LblSignalRCV.Name = "LblSignalRCV"
        Me.LblSignalRCV.Size = New System.Drawing.Size(215, 105)
        Me.LblSignalRCV.TabIndex = 3
        Me.LblSignalRCV.Text = "LblSignalRCV"
        Me.LblSignalRCV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(215, 27)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "#Signal Status"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.lblAGVName, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.ListInQueue1, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 3
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.89552!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.10448!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 442.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(219, 577)
        Me.TableLayoutPanel3.TabIndex = 2
        '
        'lblAGVName
        '
        Me.lblAGVName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblAGVName.AutoSize = True
        Me.lblAGVName.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAGVName.Location = New System.Drawing.Point(3, 28)
        Me.lblAGVName.Name = "lblAGVName"
        Me.lblAGVName.Size = New System.Drawing.Size(213, 106)
        Me.lblAGVName.TabIndex = 4
        Me.lblAGVName.Text = "lblAGVName"
        Me.lblAGVName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListInQueue1
        '
        Me.ListInQueue1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ListInQueue1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListInQueue1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListInQueue1.FormattingEnabled = True
        Me.ListInQueue1.ItemHeight = 14
        Me.ListInQueue1.Location = New System.Drawing.Point(3, 137)
        Me.ListInQueue1.Name = "ListInQueue1"
        Me.ListInQueue1.Size = New System.Drawing.Size(213, 437)
        Me.ListInQueue1.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(213, 28)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "#AGV Status"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.TableLayoutPanel2)
        Me.SplitContainer4.Size = New System.Drawing.Size(454, 131)
        Me.SplitContainer4.SplitterDistance = 306
        Me.SplitContainer4.TabIndex = 13
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.CheckBox1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.TableLayoutPanel5)
        Me.SplitContainer3.Size = New System.Drawing.Size(306, 131)
        Me.SplitContainer3.SplitterDistance = 166
        Me.SplitContainer3.TabIndex = 13
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(12, 8)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(81, 17)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label1, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.lblGetportrcv, 1, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.lblRXCount, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.btnConnectRCV, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label14, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.status0, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label17, 0, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 4
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(136, 131)
        Me.TableLayoutPanel5.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 25)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Com NO."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGetportrcv
        '
        Me.lblGetportrcv.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportrcv.AutoSize = True
        Me.lblGetportrcv.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportrcv.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportrcv.Location = New System.Drawing.Point(64, 53)
        Me.lblGetportrcv.Name = "lblGetportrcv"
        Me.lblGetportrcv.Size = New System.Drawing.Size(68, 25)
        Me.lblGetportrcv.TabIndex = 13
        Me.lblGetportrcv.Text = "com1"
        Me.lblGetportrcv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRXCount
        '
        Me.lblRXCount.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRXCount.AutoSize = True
        Me.lblRXCount.BackColor = System.Drawing.Color.Transparent
        Me.lblRXCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRXCount.Location = New System.Drawing.Point(64, 27)
        Me.lblRXCount.Name = "lblRXCount"
        Me.lblRXCount.Size = New System.Drawing.Size(68, 25)
        Me.lblRXCount.TabIndex = 11
        Me.lblRXCount.Text = "00000"
        Me.lblRXCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(4, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "RX Count:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectRCV
        '
        Me.btnConnectRCV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectRCV.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectRCV.Location = New System.Drawing.Point(64, 82)
        Me.btnConnectRCV.Name = "btnConnectRCV"
        Me.btnConnectRCV.Size = New System.Drawing.Size(68, 45)
        Me.btnConnectRCV.TabIndex = 3
        Me.btnConnectRCV.Text = "*connect*"
        Me.btnConnectRCV.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.LightGray
        Me.Label14.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(4, 79)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 51)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "[1]RCV PORT:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'status0
        '
        Me.status0.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.status0.AutoSize = True
        Me.status0.BackColor = System.Drawing.Color.Transparent
        Me.status0.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status0.Location = New System.Drawing.Point(64, 1)
        Me.status0.Name = "status0"
        Me.status0.Size = New System.Drawing.Size(68, 25)
        Me.status0.TabIndex = 14
        Me.status0.Text = "null"
        Me.status0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(4, 1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(53, 25)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Status:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblGetportSend, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblTxCntSend, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnConnectSend, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtstatus1, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(144, 131)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(4, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(57, 25)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Com NO."
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGetportSend
        '
        Me.lblGetportSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportSend.AutoSize = True
        Me.lblGetportSend.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportSend.Location = New System.Drawing.Point(68, 53)
        Me.lblGetportSend.Name = "lblGetportSend"
        Me.lblGetportSend.Size = New System.Drawing.Size(72, 25)
        Me.lblGetportSend.TabIndex = 13
        Me.lblGetportSend.Text = "com1"
        Me.lblGetportSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTxCntSend
        '
        Me.lblTxCntSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTxCntSend.AutoSize = True
        Me.lblTxCntSend.BackColor = System.Drawing.Color.Transparent
        Me.lblTxCntSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTxCntSend.Location = New System.Drawing.Point(68, 27)
        Me.lblTxCntSend.Name = "lblTxCntSend"
        Me.lblTxCntSend.Size = New System.Drawing.Size(72, 25)
        Me.lblTxCntSend.TabIndex = 11
        Me.lblTxCntSend.Text = "00000"
        Me.lblTxCntSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "RX Count:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectSend
        '
        Me.btnConnectSend.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectSend.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectSend.Location = New System.Drawing.Point(68, 82)
        Me.btnConnectSend.Name = "btnConnectSend"
        Me.btnConnectSend.Size = New System.Drawing.Size(72, 45)
        Me.btnConnectSend.TabIndex = 3
        Me.btnConnectSend.Text = "*connect*"
        Me.btnConnectSend.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.LightGray
        Me.Label6.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 79)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 51)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "[2]SERIAL PORT:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtstatus1
        '
        Me.txtstatus1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtstatus1.AutoSize = True
        Me.txtstatus1.BackColor = System.Drawing.Color.Transparent
        Me.txtstatus1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus1.Location = New System.Drawing.Point(68, 1)
        Me.txtstatus1.Name = "txtstatus1"
        Me.txtstatus1.Size = New System.Drawing.Size(72, 25)
        Me.txtstatus1.TabIndex = 14
        Me.txtstatus1.Text = "null"
        Me.txtstatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 25)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Status:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'BackgroundWorker1
        '
        '
        'BackgroundWorker4
        '
        '
        'BackgroundWorker5
        '
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'mainChat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 742)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "mainChat"
        Me.Text = "D76 Store Mole"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer4.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.PerformLayout()
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents StatusLabel_adapter As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel_send As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel_receive As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents SplitContainer4 As SplitContainer
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label9 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblGetportSend As Label
    Friend WithEvents lblTxCntSend As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnConnectSend As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents txtstatus1 As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents ListInQueue1 As ListBox
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents lblGetportrcv As Label
    Friend WithEvents lblRXCount As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnConnectRCV As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents status0 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker4 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker5 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Timer1 As Timer
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents lblC3 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblC2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblC1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lbltimeC1 As Label
    Friend WithEvents lbltimeC2 As Label
    Friend WithEvents lbltimeC3 As Label
    Friend WithEvents lbout As ListBox
    Friend WithEvents TstaTCPSignal As Label
    Friend WithEvents LblSignalRCV As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAGVName As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents CheckBox1 As CheckBox
End Class
