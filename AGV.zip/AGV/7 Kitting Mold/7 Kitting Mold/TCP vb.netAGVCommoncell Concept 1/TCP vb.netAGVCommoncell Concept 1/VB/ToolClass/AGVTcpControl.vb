﻿Imports System.IO
Imports System.Net.Sockets

' bbb
Public Class AGVTcpControl
    Public client As TcpClient
    Public s As NetworkStream
    Public sr As StreamReader
    Public sw As StreamWriter

    Public isTryConnecting As Boolean = False

    Public config As ComConfigure = New ComConfigure()

    Public received As Integer = 0

    Public milliseconds As Long = 0
    Public Shared Master_cell, Master_process, Master_circleTime As String
    Public Function Connect() As Boolean

        client = New TcpClient()

        Dim re As Boolean = False

        Try
            client.Connect(config.MyIPHost, config.MyPortHost)
            s = client.GetStream()
            sr = New StreamReader(s)
            sw = New StreamWriter(s)
            sw.AutoFlush = True
            Dim a As String = sr.ReadLine()

            sw.WriteLine("TYPE1")

            re = True

        Catch ex As Exception

        End Try

        Return re
    End Function

    Public Function GetTimeStamp() As Long
        Return CLng(DateTime.UtcNow.Subtract(New DateTime(1970, 1, 1)).TotalMilliseconds)
    End Function

    Public Function Receive() As String
        Return sr.ReadLine()
    End Function
    Public Function IsNext() As Boolean
        If GetTimeStamp() - milliseconds > 20000 Then
            milliseconds = GetTimeStamp()
            received = received + 1
            Return True
        Else
            Return False
        End If
    End Function

    Public Function Ping() As Boolean
        Dim b As Boolean = False
        Try
            sw.WriteLine("ping")
            b = True

        Catch ex As Exception
        End Try

        Return b
    End Function

End Class
