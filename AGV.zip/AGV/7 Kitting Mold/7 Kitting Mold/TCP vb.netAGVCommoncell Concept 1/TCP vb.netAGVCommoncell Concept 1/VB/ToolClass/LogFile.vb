﻿Imports System.IO

Public Class LogFile

    Dim path As String
    Dim append As Boolean

    Public Sub New(ByVal path As String, ByVal append As Boolean)
        Me.path = path
        Me.append = append
    End Sub

    Public Sub Log(ByVal message As String)
        Dim sw As StreamWriter = File.AppendText(path & "_" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".txt")
        WriteText(message, sw)
        sw.Close()
    End Sub

    Public Sub WriteText(ByVal message As String, ByVal tw As TextWriter)
        tw.WriteLine(DateTime.Now.ToString() & vbTab & message)
    End Sub

End Class
