﻿Public Class QueueManage
    Shared Sub deDequeue_AGV(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        Try
            If objT.Count <> 0 Then
                Dim str As String = String.Empty
                Dim ob As Object
                ob = objT.Dequeue()
                str = DirectCast(ob, String)
            Else
                'MessageBox.Show("queue is empty")
            End If
        Catch ex As Exception
            'logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Shared Sub Peek_1(ByRef objT As Queue(Of String), ByRef data_S() As Byte, ByRef strdata As String, ByRef ADD() As Byte, ByRef Respond As Byte, ByRef card() As Byte)
        Try
            If objT.Count <> 0 Then
                ' data_S = Nothing
                Dim str As String = String.Empty
                Dim ob As Object
                ob = objT.Peek()
                str = DirectCast(ob, String)
                strdata = str
                data_S = Reconvert.convert(str, " ")
                ADD = {data_S(0), data_S(1), data_S(2), data_S(3)}
                Dim stradd As String = Nothing
                For Each byteadd As String In ADD
                    stradd &= Hex(byteadd).ToString.PadLeft(2, "0"c) & " "
                Next
            ElseIf objT.Count = 0 Then
                '   lblmsg.Text = "Not Have AGV In Queue"
            End If
        Catch ex As Exception
            '  logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub

    Shared Sub Enqueue_AGV(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox, ByVal strtt As String)
        Try
            ' If obj.Count <> 0 Then
            Dim str As String = String.Empty
            str = strtt
            Dim ob As Object = DirectCast(str, Object)
            objT.Enqueue(CStr(ob))
            '  ToArray(objT, ListInQueue)

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub

End Class
