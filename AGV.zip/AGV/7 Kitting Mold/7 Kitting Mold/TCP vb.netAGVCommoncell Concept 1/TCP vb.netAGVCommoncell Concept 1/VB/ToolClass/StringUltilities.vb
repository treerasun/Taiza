﻿Public Class StringUltilities

    Shared Function ByteArrayToHexString(ByRef data() As Byte) As String
        Dim HexString As String = ""
        For i As Integer = 0 To data.Length - 1
            HexString &= String.Format(" {0:X2}", data(i))
        Next
        Return HexString
    End Function

End Class
