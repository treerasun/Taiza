﻿Module Delay_Function
    Sub Delay(ByVal dblsec As Double)
        Try
            Const OneSec As Double = 1.0# / (1440.0# * 60.0#)
            Dim dblWaitTil As Date
            dblWaitTil = Now.AddSeconds(OneSec).AddSeconds(dblsec)
            Do Until Now > dblWaitTil
                Application.DoEvents()
            Loop
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Module
