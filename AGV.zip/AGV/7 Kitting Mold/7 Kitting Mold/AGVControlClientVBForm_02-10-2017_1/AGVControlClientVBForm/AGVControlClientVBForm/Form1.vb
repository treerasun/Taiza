﻿Imports System.IO
Imports System.Net.Sockets

Public Class Form1

    Dim client As TCPControlClient

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        client = New TCPControlClient()

        If TextBox4.Text.Length = 0 Then
            ThreadProcSafeTextBox("There is no message to send")
        Else

            Dim r As String = client.Connect(TextBox1.Text, TextBox2.Text, TextBox4.Text)
            If r = "true" Then
                ' Button1.Text = "Disconnect"
                ThreadProcSafeTextBox("Connected to " & TextBox1.Text & ":" & TextBox2.Text)
                ThreadProcSafeTextBox("Send message: """ & TextBox4.Text & """")
            Else
                ' Button1.Text = "Connect"
                ThreadProcSafeTextBox(r)
            End If

        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'If client.Connect(TextBox1.Text, TextBox2.Text) Then
        '    ' Button1.Text = "Disconnect"
        '    ThreadProcSafeTextBox("Connected to " & TextBox1.Text & ":" & TextBox2.Text)
        'Else
        '    ' Button1.Text = "Connect"
        '    ThreadProcSafeTextBox("Disconnected")
        'End If
        TextBox4.Select()

    End Sub

    Delegate Sub SetTextCallback2(ByVal text As String)

    Public Sub ThreadProcSafeTextBox(ByVal text As String)
        Me.SetTextBox(text)
    End Sub

    Public myQueue As Queue(Of String) = New Queue(Of String)()

    Private Sub SetTextBox(ByVal Text As String)
        If Me.TextBox3.InvokeRequired Then
            Dim d As SetTextCallback2 = New SetTextCallback2(AddressOf SetTextBox)
            Me.Invoke(d, New Object() {Text})
        Else
            If (myQueue.Count >= 30) Then
                myQueue.Dequeue()
            End If

            myQueue.Enqueue(Text)

            Dim c As Integer = myQueue.Count
            Dim s As String = ""

            For i As Integer = 0 To c - 1 Step 1
                s = s & myQueue.ElementAt(i) & Environment.NewLine
            Next

            Me.TextBox3.Text = s
            Me.TextBox3.SelectionStart = Me.TextBox3.Text.Length
            Me.TextBox3.ScrollToCaret()
        End If
    End Sub

End Class
