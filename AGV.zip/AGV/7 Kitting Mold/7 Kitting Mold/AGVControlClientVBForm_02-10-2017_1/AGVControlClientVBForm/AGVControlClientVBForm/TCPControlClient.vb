﻿Imports System.IO
Imports System.Net.Sockets
Imports System.Threading

Public Class TCPControlClient

    Dim client As New TcpClient()
    Dim s As Stream
    Dim sr As StreamReader
    Dim sw As StreamWriter

    Public Function Connect(ByVal ip As String, ByVal port As Integer, ByVal text As String) As String
        Try
            client.Connect(ip, port)

            s = client.GetStream()
            sr = New StreamReader(s)
            sw = New StreamWriter(s)

            sw.AutoFlush = True
            Console.WriteLine(sr.ReadLine())

            'sw.WriteLine("send")
            'sw.WriteLine("C3-1|SUB|59")
            sw.WriteLine(text)

            Dim ctThread As Thread = New Thread(AddressOf GetMessage)
            ctThread.IsBackground = True
            ctThread.Start()

            Return "true"

        Catch ex As Exception
            'Console.WriteLine(ex.Message.ToString())
            Return ex.Message.ToString()
        End Try

    End Function

    Private Sub SendMessage(ByVal text As String)

    End Sub

    Private Sub GetMessage()

        While True
            Dim s As String = sr.ReadLine()
            Console.WriteLine(s)
        End While

    End Sub

End Class
